import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { FormsModule } from '@angular/forms';
import { ShowDetailsComponent } from './show-details/show-details.component';
import { DepositeComponent } from './deposite/deposite.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransactionComponent } from './transaction/transaction.component';
import { TransferFundComponent } from './transfer-fund/transfer-fund.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateAccountComponent,
    ShowDetailsComponent,
    DepositeComponent,
    WithdrawComponent,
    TransactionComponent,
    TransferFundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

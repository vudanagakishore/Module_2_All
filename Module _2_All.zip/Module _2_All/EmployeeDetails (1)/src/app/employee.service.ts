import { Injectable } from '@angular/core';
import { IEmployee } from './iemployee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 employees:IEmployee[]=[
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000},
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000},
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000},
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000},
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000},
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000},
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000},
   {id:1001,name:"Mark",gender:"Male",age:23,salary:26000}
 ];
  constructor() { }  
  getemployees():IEmployee[]{
    return this.employees;

  }
  addEmployee(emp){
    this.employees.push(emp);
  }
}

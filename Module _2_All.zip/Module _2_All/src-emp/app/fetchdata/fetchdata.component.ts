import { Component, OnInit } from '@angular/core';
import { ServicService, Employee } from '../service.service';


@Component({
  selector: 'app-fetchdata',
  templateUrl: './fetchdata.component.html',
  styleUrls: ['./fetchdata.component.css']
})
export class FetchdataComponent implements OnInit {

  service : ServicService;
  dept : Employee[];

  name;id;phone;

  constructor(service : ServicService) {
    this.service = service;
   }

  ngOnInit() {
    this.service.fetchData();
    this.dept = this.service.getData();
  }

  // delete(e){
  //   let check:number = -1;
  //   for(let i=0; i<this.dept.length; i++) {
  //     if(e == this.dept[i].id) {
  //       check = i;
  //       break;
  //     }
  //   }
  //   this.dept.splice(check, 1);
  //   }
 
  delete(e){
    let index = this.dept.indexOf(e);
    this.dept.splice(index, 1);
  }


isUpdate : boolean =false;
  
updateData(d:Employee){
   
    this.isUpdate = !this.isUpdate;
    this.name=d.name;
    this.id = d.id;
    this.phone = d.phone;
    
  }

  update(data : any){
    this.service.update(data);
    this.dept = this.service.getData();
    }

    column:string;
    bool:boolean = false;
    sort(value) {
        this.column = value;
        this.bool = !this.bool;
      }

}


import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { FetchdataComponent } from './fetchdata/fetchdata.component';
import { AdddataComponent } from './adddata/adddata.component';
import { SearchdataComponent } from './searchdata/searchdata.component';
const routes: Routes = [
    {
        path : 'app-fetchdata',
        component : FetchdataComponent
    },
    {
        path : 'app-adddata',
        component : AdddataComponent
    },
    {
        path: 'app-searchdata',
        component : SearchdataComponent
    }
];


@NgModule({

    imports: [RouterModule.forRoot(routes)],
  
    exports: [RouterModule]
  
  })
  
  export class AppRoutingModule { }
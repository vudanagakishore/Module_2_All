import { Component, OnInit } from '@angular/core';
import { ServicService, Employee } from '../service.service';


@Component({
  selector: 'app-searchdata',
  templateUrl: './searchdata.component.html',
  styleUrls: ['./searchdata.component.css']
})
export class SearchdataComponent implements OnInit {

  service : ServicService;
  emp : Employee[];
  constructor(service:ServicService) {
    this.service = service;
   }

  ngOnInit() {
  }

  search(data) {
    this.emp=this.service.search(data);
    }
}

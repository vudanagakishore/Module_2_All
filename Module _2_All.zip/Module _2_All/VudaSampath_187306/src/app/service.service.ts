import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServicService {

  http : HttpClient;
  service : ServicService;

  emp : Employee[] = [];
  
  constructor(http : HttpClient) {
    this.http = http;
   }

   fetch : boolean = false;

   fetchData(){
     this.http.get('./assets/Employee.json').subscribe(
       data =>{
         if(!this.fetch){
           this.convert(data);
           this.fetch = true;
         }
       }
     )
   }

   convert(data : any){
     for(let dd of data["Names"]){
       let e = new Employee(dd.Id, dd.EmployeeName, dd.Email, dd.Phone);
       this.emp.push(e);
     }
   }

   getData() : Employee[]{
     return this.emp;
   }

   add(emp : Employee){
     let e = new Employee(emp.Id, emp.EmployeeName,emp.Email,emp.Phone);
     this.emp.push(e);
   }


  //  update(data : Employee){
  //    let eId = data.Id;
  //    for(let i=0; i<this.emp.length; i++){
  //      if(eId == this.emp[i].Id){
  //        this.emp[i].EmployeeName = data.EmployeeName;
         
  //        this.emp[i].Phone = data.Phone;
  //        break;
  //      }
  //    }
  //  }

employee1: Array<Employee>
 search(data):Employee[] {
 this.employee1=[];
 for(let e of this.emp) {
 if(e.Id==data.Id) {
 this.employee1.push(e);
 }
 }
 return this.employee1;
 }
}

export class Employee{
  Id : number;
  EmployeeName : string;
  Email : string;
  Phone : number;
  constructor(Id : number, EmployeeName : string ,Email : string ,Phone : number){
      this.Id = Id;
      this.EmployeeName = EmployeeName;
      this.Email = Email;
      this.Phone = Phone;
  }
}
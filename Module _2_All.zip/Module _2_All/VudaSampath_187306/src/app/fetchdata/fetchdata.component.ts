import { Component, OnInit } from '@angular/core';
import { ServicService, Employee } from '../service.service';


@Component({
  selector: 'app-fetchdata',
  templateUrl: './fetchdata.component.html',
  styleUrls: ['./fetchdata.component.css']
})
export class FetchdataComponent implements OnInit {

  service : ServicService;
  dept : Employee[];

  EmployeeName;Id;Email;Phone;

  constructor(service : ServicService) {
    this.service = service;
   }

  ngOnInit() {
    this.service.fetchData();
    this.dept = this.service.getData();
  }


 
  delete(e){
    let index = this.dept.indexOf(e);
    this.dept.splice(index, 1);
  }




    column:string;
    bool:boolean = false;
    sort(value) {
        this.column = value;
        this.bool = !this.bool;
      }

}


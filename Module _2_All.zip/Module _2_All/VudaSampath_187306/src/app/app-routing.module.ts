import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { FetchdataComponent } from './fetchdata/fetchdata.component';
import { AdddataComponent } from './adddata/adddata.component';

const routes: Routes = [
    {
        path : 'app-fetchdata',
        component : FetchdataComponent

    },
    {
        path : 'app-adddata',
        component : AdddataComponent
    },
    {
        path : '',redirectTo: '/app-fetchdata',pathMatch: 'full'
    
    }


];


@NgModule({

    imports: [RouterModule.forRoot(routes)],
  
    exports: [RouterModule]
  
  })
  
  export class AppRoutingModule { }
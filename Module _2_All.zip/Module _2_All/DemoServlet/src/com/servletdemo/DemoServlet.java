package com.servletdemo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DemoServlet
 */

//@WebServlet(name = "DemoServlet", urlPatterns = {"/DemoServlet"},initParams = {@WebInitParam(description="jdbc:oracle:thin:@localhost:1521:xe",name="system",value="India123")})
//@WebServlet(name = "HelloServlet", urlPatterns= {"/HelloServlet"},initParams = {@WebInitParam(name = "fileName",value="Data")})
@WebServlet(name = "DemoServlet", urlPatterns = {"/DemoServlet"},initParams = {
        @WebInitParam(name="uname",value="system"),
        @WebInitParam(name="pswd",value="India123"),
        @WebInitParam(name="url",value="jdbc:oracle:thin:@localhost:1521:xe"),
        }
)
public class DemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DemoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ServletConfig config =getServletConfig();
		String name = request.getParameter("username");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String qualification = request.getParameter("qualification");
		String proofs = request.getParameter("proofs");
		String hobbies = request.getParameter("hobbies");
		 String uname =  config.getInitParameter("uname");
	      String pass = config.getInitParameter("pswd");
	       String urls = config.getInitParameter("url");
		out.print("Your name :"+name);
		out.print("Your password"+password);
		out.print("Gender"+gender);
		out.print("Qualification"+qualification);
		out.print("Proofs:"+proofs);
		out.print("Hoobies"+hobbies);
		
		try           
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con = DriverManager.getConnection(urls,uname,pass);
			
			PreparedStatement stmt  = con.prepareStatement("insert into userdetails values(?,?,?,?,?)");
			stmt.setString(1, name);
			stmt.setString(2,password);
			stmt.setString(3,gender);
			stmt.setString(4,qualification);
			stmt.setString(5,hobbies);
			stmt.executeUpdate();
			System.out.println("record added succesfully");
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

export{}
let greeting  =  "Say Hi";

let times = 4;

if(times > 3)
{
    let hello = "say Hello instead";
    console.log(hello);
}
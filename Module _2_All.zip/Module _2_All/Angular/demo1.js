"use strict";
exports.__esModule = true;
var greeting = "Say Hi";
var times = 4;
if (times > 3) {
    var hello = "say Hello instead";
    console.log(hello);
}

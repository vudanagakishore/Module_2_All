/*function add(n1: number, n2: number)
{
    return(n1+n2);
}

console.log(add(22,33));*/

export { }

function add(n1: number, n2?: number) {
    if (isNaN(n2)) {
        return n1;
    }
    else {
        return n1 + n2;
    }
}
console.log(add(50));
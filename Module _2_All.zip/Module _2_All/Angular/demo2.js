export{}
var abc1;
abc = "Capgemini";
abc = "200";
console.log(abc);

let abc : any;

abc = "Capgemini";

abc = "200";

console.log(abc);
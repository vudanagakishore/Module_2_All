"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var Employee = /** @class */ (function () {
    function Employee(id, name) {
        this.id = id;
        this.name = name;
    }
    Employee.prototype.showDetails = function () {
        console.log("id and name:" + this.id + " " + this.name);
    };
    return Employee;
}());
var e = new Employee(12, "brock");
e.showDetails();
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager(id, name) {
        return _super.call(this, id, name) || this;
    }
    Manager.prototype.getName = function () {
        console.log("name: " + name);
    };
    return Manager;
}(Employee));
var v = new Manager(10, "brock");
v.showDetails();

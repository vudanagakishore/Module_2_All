export{}
class Employee
{
    public id : number;
    public name: string;

    constructor(id: number, name: string)
    {
       
        this.id = id; 
        this.name=name;
    }
    showDetails()
    {
        console.log(`id and name:${this.id} ${this.name}`);
        
    }
}

let e = new Employee(12,"brock");
e.showDetails();

class Manager extends Employee
{
    constructor(id:number, name: string)
    {
        super(id,name);
    }

    getName()
    {
        console.log(`name: ${name}`);
    }
}

let v = new Manager(10,"brock");
v.showDetails();


import { Component, OnInit } from '@angular/core';
import { StudentServiceService } from '../student-service.service';
import { Student } from '../Student';

@Component({
  selector: 'app-show-student',
  templateUrl: './show-student.component.html',
  styleUrls: ['./show-student.component.css']
})
export class ShowStudentComponent implements OnInit {
Student:StudentServiceService;
StuArr:Student[]=[];
updateboo:boolean=true;
column:string; 
order:boolean=true;

name;id;

  constructor(Student:StudentServiceService) {
    this.Student=Student;
   }
deleteData(st){
  let index=this.StuArr.indexOf(st);
  this.StuArr.splice(index,1);

}
update(st:Student){
  this.updateboo=!this.updateboo;
  this.id=st.id;
  this.name=st.name;


}
UpdateData(d:Student){
  this.Student.updateDaw(d);

}

sort(column:string){
  
  if(this.column==column)
  {
    this.order=!this.order;
  }else{
    this.order=true;
    this.column=column;
  }
}

  ngOnInit() {
    this.Student.fetchData();
    this.StuArr=this.Student.getData();

  }

}

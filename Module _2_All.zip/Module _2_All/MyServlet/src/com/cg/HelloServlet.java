package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;

/**
 * Servlet implementation class HelloServlet
 */
@WebServlet(name = "HelloServlet", urlPatterns= {"/HelloServlet"},initParams = {@WebInitParam(name = "fileName",value="Data")})
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		ServletConfig config = getServletConfig();
		String names = request.getParameter("uname");
		String result = config.getInitParameter("fileName");
		
		if(names.equals("raja"))
		{
			RequestDispatcher rd = request.getRequestDispatcher("/success.html");
			rd.forward(request, response);
			
			out.print(result);
		
		//out.println("Hello Servlet");
		Enumeration headerNames = request.getHeaderNames();
		while(headerNames.hasMoreElements())
		{
			String name = (String) headerNames.nextElement();
			String value = request.getHeader(name);
			if(value!=null)
			{
				out.println(name+" : "+value);
			}
		}
	}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

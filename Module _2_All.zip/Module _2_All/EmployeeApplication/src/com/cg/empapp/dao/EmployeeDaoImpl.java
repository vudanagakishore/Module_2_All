package com.cg.empapp.dao;

import java.util.HashMap;

import com.cg.empapp.dto.Employee;

/**
 * class to perform business logic
 */
public class EmployeeDaoImpl implements EmployeeDao{
	
	/**
    * map to hold the data
    */
	private static HashMap<Integer,Employee> map=new HashMap<Integer,Employee>();
	
    
    
    /**
    * getter for map
    */   
    public static void setMap(HashMap<Integer,Employee> map)
    {
		EmployeeDaoImpl.map=map;
    }  
    
    /**
     * Setter for the map
     */

    public static HashMap<Integer,Employee> getMap()
    {
		return map;
    }  

   

}